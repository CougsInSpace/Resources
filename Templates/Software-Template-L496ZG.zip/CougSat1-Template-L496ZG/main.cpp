// Simple I2C responder
#include <mbed.h>
#include <rtos.h>
#include "src/tools/SWO.h"

DigitalOut led1(PB_14);
SWO_Channel swo;

void blink(){
	led1 = !led1;
    swo.printf("Blink\n");
}

int main() {
    // creates a queue with the default size
    EventQueue queue;
    swo.printf("Hello World\n");
    // events are simple callbacks
    //queue.call(swo.printf, "Hello\n");
    queue.call_every(500, blink);

    // events are executed by the dispatch method
    queue.dispatch();
}
